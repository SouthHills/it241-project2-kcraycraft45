# Speech Finalized

Date: November 2, 2024
Assign: Kaci Craycraft, Rachel Henninger
Status: Not started
Project Portion: Speech