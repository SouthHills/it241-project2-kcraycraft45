# Review Rachel’s written section / proofread

Date: November 3, 2024
Assign: Kaci Craycraft
Status: Done
Project Portion: Paper