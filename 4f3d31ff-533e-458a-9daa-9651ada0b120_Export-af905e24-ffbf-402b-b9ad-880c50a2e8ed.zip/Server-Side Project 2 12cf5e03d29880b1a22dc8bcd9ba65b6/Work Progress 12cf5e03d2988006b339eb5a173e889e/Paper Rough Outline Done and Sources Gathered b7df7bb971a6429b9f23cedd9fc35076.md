# Paper: Rough Outline Done and Sources Gathered

Date: October 28, 2024
Status: Done
Project Portion: Paper