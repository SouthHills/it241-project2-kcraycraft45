# Research

SQL injection can destroy your database.  It is a very common hacking technique involving the injection of malicious code in SQL statements to input fields on web pages.

Instead of inputting their username and password, the user gives a statement that will run in your database.

---

Example:

```csharp
txtUserId = getRequestString("UserId");
txtSQL = "SELECT * FROM Users WHERE UserID = " + txtUserId;
```

### SQL Injection based on 1=1 is always true

- Purpose of above code creates a SQL statement to select a user with a given user id
- Now if we put in:

![image.png](Research%2012cf5e03d29880daa1dfe55337480cce/image.png)

- SQL statement becomes
    
    ```sql
    SELECT * FROM Users WHERE UserId = 105 or 1=1;
    ```
    
- This returns ALL ROWS from the Users table since <OR 1=1> is always TRUE.
- This is the same as:
    
    ```sql
    SELECT UserId, Name, Password FROM Users WHERE UserId = 105 or 1=1;
    ```
    

---

### SQL Injection Based on “”=”” is Always True:

![image.png](Research%2012cf5e03d29880daa1dfe55337480cce/image%201.png)

```csharp
username = getRequestString("username");
password = getRequestString("userpassword");

sql = 'SELECT * FROM Users WHERE Name ="' + username + '" AND Pass="' + password + '"';
```

![image.png](Research%2012cf5e03d29880daa1dfe55337480cce/image%202.png)

```sql
// This results in
SELECT * FROM Users WHERE Name="" or ""="" AND Pass="" or ""=""
// This is valid and returns all rows from the Users table
```

---

### Use SQL Parameters for Protection

- To protect a website from SQL injection, you can use SQL parameters
    - SQL Parameters - values that are added to a SQL Query at execution time, in a controlled manner.
        - Represented in the SQL statement by an @ marker.
        - The SQL engine checks each parameter to ensure that it is correct for its column and are treated literally, and not as part of the SQL to be executed.
        
        ![image.png](Research%2012cf5e03d29880daa1dfe55337480cce/image%203.png)
        

---

### How to build parameterized queries in PHP

```sql
$stmt = $dbh->prepare("INSERT INTO Customers (CustomerName,Address,City)
VALUES (:nam, :add, :cit)");
$stmt->bindParam(':nam', $txtNam);
$stmt->bindParam(':add', $txtAdd);
$stmt->bindParam(':cit', $txtCit);
$stmt->execute();
```

---

SQL injection in an application occurs if it has dynamic database queries that use string concatenation and user supplied input.

- To avoid SQL injection flaws,
developers need to:
    1. Stop writing dynamic queries with string concatenation
    2. Prevent malicious sql input from being included in executed queries.

---

### Primary Defenses

1. Use of prepared statements (with parameterized queries)
    - Parameterized queries: prepared statements with variable binding.
    - Prepared statements are simpler to write and easier to understand than dynamic queries
    - Parameterized queries force the developer to define all SQL code first and pass in each parameter to the query later.
    - If database queries use this coding style, the database will always distinguish between code and data,
        - regardless of what user input is supplied
    - Prepared statements ensure that an attacker is not able to change the intent of a query even if SQL commands are inserted by an attacker
        
        ```java
        // This should also be validated
        String custname = request.getParameter("customerName");
        // Perform input validation to detect attacks
        String query = "SELECT account_balance FROM user_data WHERE user_name = ? ";
        PreparedStatement pstmt = connection.prepareStatement(query);
        pstmt.setString(1, custname);
        ResultSet results = pstmt.executeQuery();
        ```
        
        - If an attacker enters “ tom’ or ‘1’=’1 “,
            - The parameterized query looks for a username that exactly matches “tom’ or ‘1’=’1 “.
        - PreparedStatement is Java’s implementation of a parameterized query.
    - ALL languages support parameterized query interfaces.
    - Developers favor prepared statements because all of the SQL code stays within the application which makes your application relatively database independent.
2. Use of properly constructed stored procedures
    - Not always safe from SQL injection
        - Developers can use certain standard stored procedure programming constructs.
        - Same effect as the use of parameterized queries
            - As long as the stored procedures are implemented afely
                - Which is the norm for most stored procedure languages
    - Safe Approach
        - Requires the developer to build SQL statements with parameters that are automatically parameterized
            - Unless the developer does something largely out of the norm
        - Difference between prepared statements and stored procedures:
            - The SQL code for a stored procedure is defined and stored in the database itself, and then called from the application
            - Since prepared statements and safe stored procedures are equally effective in preventing SQL injection, your organization should choose the approach that makes the most sense for you.
    - Risky Stored Procedures
        - Can increase risk when a system is attacked.
            - Stored procedures require execute rights
                - (on a server that an administrator must allocate read/write/execute permissions to users)
                - In set ups where user management has been centralized, but is limited to those 3 roles, web apps would have to run as db_owner, so stored procedures could work.
                    - That means that if a server is breached, the attacker has FULL RIGHTS to the database, where they normally would just have read-access.
    - A stored procedure is a subroutine stored in the database catalog.
        - Applications can call and execute a stored procedure.
        - IN / INOUT / OUT parameters.
            - IN
                - Provided with the CALL statement.
3. Allow-list input validation
    - *Left of here to write more code*
4. STRONGLY DISCOURAGED: escaping all user supplied input.
    1. (htmlentities? I assume)

---