# Created username/password database…

Date: October 27, 2024
Status: Done
Project Portion: SQL

[Screen Recording](Created%20username%20password%20database%E2%80%A6%2012cf5e03d29880bcb8bacece95662f82/Untitled_video_-_Made_with_Clipchamp_(1).mp4)

[Commands for Username/Password table](Created%20username%20password%20database%E2%80%A6%2012cf5e03d29880bcb8bacece95662f82/SQLQuery_2.sql)

![image.png](Created%20username%20password%20database%E2%80%A6%2012cf5e03d29880bcb8bacece95662f82/image.png)

![image.png](Created%20username%20password%20database%E2%80%A6%2012cf5e03d29880bcb8bacece95662f82/image%201.png)