# Example 1 & 2 cleaned and explained

Date: November 1, 2024
Assign: Kaci Craycraft
Status: Done
Project Portion: Code