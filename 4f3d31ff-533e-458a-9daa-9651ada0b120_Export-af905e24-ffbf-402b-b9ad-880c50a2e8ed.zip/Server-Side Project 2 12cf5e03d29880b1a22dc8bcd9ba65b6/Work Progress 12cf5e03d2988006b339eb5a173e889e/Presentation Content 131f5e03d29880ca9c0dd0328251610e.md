# Presentation Content

Date: November 2, 2024
Assign: Kaci Craycraft, Rachel Henninger
Status: Done
Project Portion: Presentation

[Project2- slide-info.docx](Presentation%20Content%20131f5e03d29880ca9c0dd0328251610e/Project2-_slide-info.docx)