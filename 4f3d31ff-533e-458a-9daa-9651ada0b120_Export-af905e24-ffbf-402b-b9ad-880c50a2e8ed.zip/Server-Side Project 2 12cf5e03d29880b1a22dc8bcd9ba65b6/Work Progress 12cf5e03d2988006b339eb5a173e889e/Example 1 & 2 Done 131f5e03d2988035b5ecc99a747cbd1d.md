# Example 1 & 2 Done

Date: October 31, 2024
Assign: Kaci Craycraft
Status: Done
Project Portion: Code