# Server-Side Project 2

### SQL Injection Project General Requirements:

- Understand and demonstrate the vulnerability,
- Show an insecure PHP example,
- Implement a secure solution using MySQL and PDO
    - Yeah… idk what PDO is either

### Repository:

- https://github.com/kcraycraft45/SQL_Injection_Prevention_Proj

[https://github.com/SouthHills/it241-project2-kcraycraft45](https://github.com/SouthHills/it241-project2-kcraycraft45)

### //TO DO

- [ ]  Research paper
- [ ]  Presentation
- [x]  Practical coding examples in PHP
- [x]  Practical coding examples in MySQL
- [x]  GitHub repository

### Photos

[Photos](Server-Side%20Project%202%2012cf5e03d29880b1a22dc8bcd9ba65b6/Photos%20130f5e03d29880ff98dec222f48b9f9e.md)

### References

[Citations](Server-Side%20Project%202%2012cf5e03d29880b1a22dc8bcd9ba65b6/Citations%2012cf5e03d2988052bc46fe39e4a74958.md)

### Research

[Research](Server-Side%20Project%202%2012cf5e03d29880b1a22dc8bcd9ba65b6/Research%2012cf5e03d29880daa1dfe55337480cce.md)

[Project2-Paper-Outline.docx](Server-Side%20Project%202%2012cf5e03d29880b1a22dc8bcd9ba65b6/Project2-Paper-Outline.docx)

### Paper

[Project2-Paper.docx](Server-Side%20Project%202%2012cf5e03d29880b1a22dc8bcd9ba65b6/Project2-Paper.docx)

*After Kaci’s Edits*: 

[Project2-Paper.docx](Server-Side%20Project%202%2012cf5e03d29880b1a22dc8bcd9ba65b6/Project2-Paper%201.docx)

[Work Progress](Server-Side%20Project%202%2012cf5e03d29880b1a22dc8bcd9ba65b6/Work%20Progress%2012cf5e03d2988006b339eb5a173e889e.csv)

# SOURCE CONTROL

- Click on three dots at top right - select version history