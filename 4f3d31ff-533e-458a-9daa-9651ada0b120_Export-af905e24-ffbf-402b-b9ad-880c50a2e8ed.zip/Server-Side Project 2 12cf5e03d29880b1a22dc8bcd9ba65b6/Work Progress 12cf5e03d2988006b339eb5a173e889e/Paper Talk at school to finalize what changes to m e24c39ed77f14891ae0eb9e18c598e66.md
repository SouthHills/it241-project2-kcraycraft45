# Paper: Talk at school to finalize what changes to make

Date: October 31, 2024
Status: Done
Project Portion: Paper